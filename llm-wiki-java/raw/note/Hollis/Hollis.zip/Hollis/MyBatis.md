# MyBatis

所有者: junk01

本分类共 **16** 篇文章。

- ✅什么是ORM，有哪些常用框架？
- ✅MyBatis与Hibernate有何不同？
- ✅Mybatis的优点有哪些？
- ✅Mybatis是如何实现字段映射的？
- ✅#和$的区别是什么？什么情况必须用$
- ✅Mybatis插件的运行原理？
- ✅Mybatis的工作原理？
- ✅Mybatis的缓存机制
- ✅Mybatis用的什么连接池？
- ✅Mybatis 是否支持延迟加载？实现原理是什么？
- ✅Mybatis可以实现动态SQL么？
- ✅使用MyBatis如何实现分页？
- ✅RowBounds分页的原理是什么？
- ✅PageHelper分页的原理是什么？
- ✅MyBatis-Plus有什么用？
- ✅MyBatis-Plus的分页原理是什么？

[✅什么是ORM，有哪些常用框架？](MyBatis/%E2%9C%85%E4%BB%80%E4%B9%88%E6%98%AFORM%EF%BC%8C%E6%9C%89%E5%93%AA%E4%BA%9B%E5%B8%B8%E7%94%A8%E6%A1%86%E6%9E%B6%EF%BC%9F.md)

[✅MyBatis与Hibernate有何不同？](MyBatis/%E2%9C%85MyBatis%E4%B8%8EHibernate%E6%9C%89%E4%BD%95%E4%B8%8D%E5%90%8C%EF%BC%9F.md)

[✅Mybatis的优点有哪些？](MyBatis/%E2%9C%85Mybatis%E7%9A%84%E4%BC%98%E7%82%B9%E6%9C%89%E5%93%AA%E4%BA%9B%EF%BC%9F.md)

[✅Mybatis是如何实现字段映射的？](MyBatis/%E2%9C%85Mybatis%E6%98%AF%E5%A6%82%E4%BD%95%E5%AE%9E%E7%8E%B0%E5%AD%97%E6%AE%B5%E6%98%A0%E5%B0%84%E7%9A%84%EF%BC%9F.md)

[✅#和$的区别是什么？什么情况必须用$](MyBatis/%E2%9C%85%23%E5%92%8C$%E7%9A%84%E5%8C%BA%E5%88%AB%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F%E4%BB%80%E4%B9%88%E6%83%85%E5%86%B5%E5%BF%85%E9%A1%BB%E7%94%A8$.md)

[✅Mybatis插件的运行原理？](MyBatis/%E2%9C%85Mybatis%E6%8F%92%E4%BB%B6%E7%9A%84%E8%BF%90%E8%A1%8C%E5%8E%9F%E7%90%86%EF%BC%9F.md)

[✅Mybatis的工作原理？](MyBatis/%E2%9C%85Mybatis%E7%9A%84%E5%B7%A5%E4%BD%9C%E5%8E%9F%E7%90%86%EF%BC%9F.md)

[✅Mybatis的缓存机制](MyBatis/%E2%9C%85Mybatis%E7%9A%84%E7%BC%93%E5%AD%98%E6%9C%BA%E5%88%B6.md)

[✅Mybatis用的什么连接池？](MyBatis/%E2%9C%85Mybatis%E7%94%A8%E7%9A%84%E4%BB%80%E4%B9%88%E8%BF%9E%E6%8E%A5%E6%B1%A0%EF%BC%9F.md)

[✅Mybatis 是否支持延迟加载？实现原理是什么？](MyBatis/%E2%9C%85Mybatis%20%E6%98%AF%E5%90%A6%E6%94%AF%E6%8C%81%E5%BB%B6%E8%BF%9F%E5%8A%A0%E8%BD%BD%EF%BC%9F%E5%AE%9E%E7%8E%B0%E5%8E%9F%E7%90%86%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F.md)

[✅Mybatis可以实现动态SQL么？](MyBatis/%E2%9C%85Mybatis%E5%8F%AF%E4%BB%A5%E5%AE%9E%E7%8E%B0%E5%8A%A8%E6%80%81SQL%E4%B9%88%EF%BC%9F.md)

[✅使用MyBatis如何实现分页？](MyBatis/%E2%9C%85%E4%BD%BF%E7%94%A8MyBatis%E5%A6%82%E4%BD%95%E5%AE%9E%E7%8E%B0%E5%88%86%E9%A1%B5%EF%BC%9F.md)

[✅RowBounds分页的原理是什么？](MyBatis/%E2%9C%85RowBounds%E5%88%86%E9%A1%B5%E7%9A%84%E5%8E%9F%E7%90%86%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F.md)

[✅PageHelper分页的原理是什么？](MyBatis/%E2%9C%85PageHelper%E5%88%86%E9%A1%B5%E7%9A%84%E5%8E%9F%E7%90%86%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F.md)

[✅MyBatis-Plus有什么用？](MyBatis/%E2%9C%85MyBatis-Plus%E6%9C%89%E4%BB%80%E4%B9%88%E7%94%A8%EF%BC%9F.md)

[✅MyBatis-Plus的分页原理是什么？](MyBatis/%E2%9C%85MyBatis-Plus%E7%9A%84%E5%88%86%E9%A1%B5%E5%8E%9F%E7%90%86%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F.md)