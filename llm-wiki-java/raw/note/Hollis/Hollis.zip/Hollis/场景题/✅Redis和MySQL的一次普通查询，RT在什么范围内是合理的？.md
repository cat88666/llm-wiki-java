# ✅Redis和MySQL的一次普通查询，RT在什么范围内是合理的？

所有者: junk01

# ✅Redis和MySQL的一次普通查询，RT在什么范围内是合理的？

> 原文：[https://www.yuque.com/hollis666/asgng6/lg07ilmsrvf1gwe5](https://www.yuque.com/hollis666/asgng6/lg07ilmsrvf1gwe5)
> 

# 典型回答

Redis是基于内存的，MySQL是基于磁盘的（非Memory引擎），所以Redis要比MySQL快，一次RT要分两部分，一部分是网络交互的耗时，一部分是命令（SQL）执行的耗时。但是不管怎么说，Redis都要比MySQL快得多。

先说下纯命令（SQL）执行耗时情况。

### **Redis命令执行耗时**

Redis的简单命令（如`GET`、`SET`）执行耗时大概在**0.1ms~1ms**（100-1000微秒）。复杂命令（如`**ZADD**`、`**HSET**`）的执行耗时大概在**1ms~5ms**左右。

下图是阿里云给出的Redis和云上服务的对比图，可以看到，Redis的P99基本都在1毫秒以内的。（测试环境：标准架构（双副本），不启用集群， 8 GB）

测评地址：[https://help.aliyun.com/zh/redis/support/performance-whitepaper-of-community-edition-instances](https://help.aliyun.com/zh/redis/support/performance-whitepaper-of-community-edition-instances)

### **MySQL的SQL运行耗时**

首先，对于MySQL来说，命中索引、命中buffer pool，无join等等都对性能有很大的影响。但是还是能给出一些大致的范围的。

如果一个查询，直接命中buffer pool并且通过主键查询，那么可能在2ms以内也能返回。比Redis慢不了多少。

如果没有命中buffer pool，就需要去磁盘读取，这时候就需要更多的耗时了，一般我们认为一次查询如果超过1秒钟算是慢SQL了，所以，**一个正常的查询语句，应该在1000ms内返回，我们普遍认为200ms-500ms以内算是比较好的一个性能了。**

以上说的不包括任何的网络交互的时长，还要再加上网络耗时，那么网络耗时怎么算的呢？

### 网络耗时

一次HTTP交互过程包括DNS解析、TCP握手、LS握手、HTTP请求、HTTP响应几个步骤了。那么一次请求（非HTTP 3.0的情况）就是：

大概3.5个RTT加上DNS解析的耗时了。

RTT是什么呢？就是一次请求的往返时间，那么这个又咋算呢，可以给个大概的参考：

### **二、典型场景下的网络耗时**

#### **1. 局域网（LAN）**

---

---

| 场景 | 平均RTT |
| --- | --- |
| 千兆以太网（同交换机） | 0.1ms~0.5ms |
| WiFi 6（近距离） | 1ms~5ms |
| 企业内网跨机房 | 1ms~2ms |

#### **2. 广域网（WAN）**

---

---

| 场景 | 平均RTT |
| --- | --- |
| 同城数据中心（≤100km） | 1ms~5ms |
| 跨省（如北京→上海） | 20ms~30ms |
| 跨国（如中国→美西） | 100ms~150ms |
| 卫星通信（如Starlink） | 20ms~50ms |

#### **3. 移动网络**

---

---

| 场景 | 平均RTT |
| --- | --- |
| 4G LTE | 30ms~100ms |
| 5G SA（Sub-6GHz） | 10ms~30ms |
| 5G毫米波（mmWave） | 1ms~10ms |