# ✅MySQL（pgsql）、Elasticsearch、mongodb、HBase、Redis，各适合什么场景？

所有者: junk01

# ✅MySQL（pgsql）、Elasticsearch、mongodb、HBase、Redis，各适合什么场景？

> 原文：[https://www.yuque.com/hollis666/asgng6/kg9m41nibkgmcsgb](https://www.yuque.com/hollis666/asgng6/kg9m41nibkgmcsgb)
> 

# 典型回答

这几种是目前比较常见的一些存储，但是他们其实差别还挺大的。

MySQL、pgsql、oracle等等都是**关系型数据库**，主要用于数据持久化存储，因为他们都支持事务，有ACID的保障，并且支持各种复杂的查询，包括join、in、子查询等。一般适合于存储如订单、支付、账户等需要强一致性和完整性的场景。

Redis是一种**非关系型数据库**，存储的是key-value，它是基于内存的，所以有高性能的特性，他也支持一些高性能的数据结构，比如zset、hash等等的，虽然它支持RDB/AOF这样的持久化机制，但是还是不建议使用Redis作为持久化数据库，一方面他不支持ACID这样的事务，还有就是内存空间本来也是比较有限的。所以建议还是用来做缓存，或者半缓存半持久化比较合适。

Elasticsearch其实是一种**搜索引擎**，因为他里面的数据多数都是通过binlog同步的方式从数据库同步过来的，所以他提供的是准实时查询，即非实时查询，有一点点的数据延迟。但是因为他支持全文索引、倒排索引，所以他对文档查询，关键词匹配查询等等很友好，查询效率会比较高。并且在海量数据的处理上，他也比mysql要更适合一些。

HBase， 构建在 HDFS 之上，而 HDFS 是 Hadoop 的核心组件，主要用于离线批处理（如 MapReduce、Spark）。所以很多时候，使用HBase的时候，以作为离线数据库为主， 可以实现海量数据的离线存储、离线计算、数据同步与分析。一般是用于做数据对账、数据统计、数据存档、数据报表等需求用的比较多。

如何选择？

- **要事务、强一致、复杂查询？** → **PostgreSQL**
- **要全文搜索、日志分析、聚合？** → **Elasticsearch**
- **高并发热点访问？  →  Redis**
- **要存 PB 级数据，离线场景  → HBase**

但是，很多业务架构中，都是混着用的，比如数据库存一份，Redis存一份，ES存一份，HBase也存一份。

数据库做事务，来保障持久化。

Redis存热点数据，做缓存，提升查询性能。

ES做搜索引擎，用于文档检索或者模糊查询。

HBase做离线核对，离线报表的生成。

# 扩展知识

## RedisMySQLMongoDB区别？