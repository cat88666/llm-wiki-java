# ✅Eureka 在 Spring Boot 3.x 之后被移除了，如何替代？

所有者: junk01

# ✅Eureka 在 Spring Boot 3.x 之后被移除了，如何替代？

> 原文：[https://www.yuque.com/hollis666/asgng6/fgsge63ygay8ml4z](https://www.yuque.com/hollis666/asgng6/fgsge63ygay8ml4z)
> 

# 典型回答

Spring Boot 3.x 移除了对 Java EE（Jakarta EE）旧 API（如 `javax` 包）的支持，而 Eureka 仍然依赖 `javax.xml.bind` 等 API，**因此官方不再维护 Eureka，并推荐其他方案。**  

Eureka的主要功能是实现服务注册中心，所以其实他的替代产品还挺多的，比如nacos、zk、consul等 。

### Nacos

**Nacos**是阿里巴巴开源的服务注册中心和配置中心。与Zookeeper不同的是，Nacos自带了配置中心功能，并提供了更多的可视化配置管理工具。Nacos的目标是成为一个更全面的云原生服务发现、配置和管理平台。

### **Consul**

**Consul**是HashiCorp开源的服务注册中心和配置中心，提供了服务发现、健康检查、KV存储和多数据中心功能。Consul提供了更丰富的健康检查和路由功能，同时也提供了丰富的API和Web UI。

### Zookeeper

**Zookeeper**是最早流行的开源分布式协调服务框架之一，同时也提供了分布式配置中心的功能。Zookeeper以高可用、一致性和可靠性著称，**但是需要用户自己来开发实现分布式配置的功能。**

对比如下：

|  | Nacos | Eureka | Consul | Zookeeper |
| --- | --- | --- | --- | --- |
| CAP | CP+AP | AP | CP | CP |
| 健康检查 | TCP/HTTP/MYSQL/Client Beat | Client Beat | TCP/HTTP/gRPC/Cmd | Keep Alive |
| 负载均衡 | 权重/metadata/Selector | Ribbon | Fabio | — |
| 一致性算法 | Raft/Distro | Gossip | Raft | ZAB |
| 雪崩保护 | 有 | 有 | 无 | 无 |
| 访问协议 | HTTP/DNS | HTTP | HTTP/DNS | TCP |
| 跨注册中心同步 | 支持 | 不支持 | 支持 | 不支持 |
| Spring Cloud集成 | 支持 | 支持 | 支持 | 支持 |
| Dubbo集成 | 支持 | 不支持 | 支持 | 支持 |
| K8s集成 | 支持 | 不支持 | 支持 | 支持 |