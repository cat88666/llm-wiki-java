# ✅Linux下rm正在写入的文件会发生什么？

所有者: junk01

# ✅Linux下rm正在写入的文件会发生什么？

> 原文：[https://www.yuque.com/hollis666/asgng6/gmiyw1c3p4i5il04](https://www.yuque.com/hollis666/asgng6/gmiyw1c3p4i5il04)
> 

# 典型回答

在 Linux 中，文件的存储由两部分组成：

- 文件名（Directory Entry）：用户看到的文件路径（如 `/data/file.txt`）。
- 文件数据（Inode 和数据块）：实际存储文件内容的磁盘空间。

`**rm**` **命令的作用是删除文件名与 inode 的链接（目录中看不到这个文件了）。如果该文件被其他进程正在写入，则 inode 和数据块不会立即释放，进程还可以继续写入（数据仍可写入），等所有进程关闭文件后再回收资源（回收文件的磁盘空间）。**

之所以这样，是因为其实在linux中，**文件数据和文件名是分开的**

- 文件名是目录中的一个“链接（link）”，指向 inode。
- 文件内容存在 inode 管理的 block 中。
- `rm` 命令只是调用 `unlink()`，移除了一个目录项。