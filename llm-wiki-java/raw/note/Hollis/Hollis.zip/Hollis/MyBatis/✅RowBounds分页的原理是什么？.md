# ✅RowBounds分页的原理是什么？

所有者: junk01

# ✅RowBounds分页的原理是什么？

> 原文：[https://www.yuque.com/hollis666/asgng6/dkzvunp0718ap32z](https://www.yuque.com/hollis666/asgng6/dkzvunp0718ap32z)
> 

# 典型回答

MyBatis的RowBounds是一个用于分页查询的简单POJO类，它包含两个属性offset和limit，分别表示分页查询的偏移量和每页查询的数据条数。

**在使用RowBounds进行逻辑分页的时候，我们的SQL语句中是不需要指定分页参数的。**就正常的查询即可，如：

然后，在查询的时候，将RowBounds当做一个参数传递：

这样，实际上在查询的时候，将会先所有符合条件的记录返回，然后再在内存中进行分页，分页的方式是根据RowBounds中指定的offset和limit进行数据保留，即抛弃掉不需要的数据再返回。