# Maven&Git

所有者: junk01

本分类共 **7** 篇文章。

- ✅Maven能解决什么问题？为什么要用？
- ✅Maven如何解决jar包冲突的问题？
- ✅Git和SVN有什么区别？
- ✅Git如何回滚代码？reset和revert什么区别？
- ✅jar包和war包有什么区别？
- ✅什么是fat jar？
- ✅Git的merge和rebase有什么区别？

[✅Maven能解决什么问题？为什么要用？](Maven&Git/%E2%9C%85Maven%E8%83%BD%E8%A7%A3%E5%86%B3%E4%BB%80%E4%B9%88%E9%97%AE%E9%A2%98%EF%BC%9F%E4%B8%BA%E4%BB%80%E4%B9%88%E8%A6%81%E7%94%A8%EF%BC%9F.md)

[✅Maven如何解决jar包冲突的问题？](Maven&Git/%E2%9C%85Maven%E5%A6%82%E4%BD%95%E8%A7%A3%E5%86%B3jar%E5%8C%85%E5%86%B2%E7%AA%81%E7%9A%84%E9%97%AE%E9%A2%98%EF%BC%9F.md)

[✅Git和SVN有什么区别？](Maven&Git/%E2%9C%85Git%E5%92%8CSVN%E6%9C%89%E4%BB%80%E4%B9%88%E5%8C%BA%E5%88%AB%EF%BC%9F.md)

[✅Git如何回滚代码？reset和revert什么区别？](Maven&Git/%E2%9C%85Git%E5%A6%82%E4%BD%95%E5%9B%9E%E6%BB%9A%E4%BB%A3%E7%A0%81%EF%BC%9Freset%E5%92%8Crevert%E4%BB%80%E4%B9%88%E5%8C%BA%E5%88%AB%EF%BC%9F.md)

[✅jar包和war包有什么区别？](Maven&Git/%E2%9C%85jar%E5%8C%85%E5%92%8Cwar%E5%8C%85%E6%9C%89%E4%BB%80%E4%B9%88%E5%8C%BA%E5%88%AB%EF%BC%9F.md)

[✅什么是fat jar？](Maven&Git/%E2%9C%85%E4%BB%80%E4%B9%88%E6%98%AFfat%20jar%EF%BC%9F.md)

[✅Git的merge和rebase有什么区别？](Maven&Git/%E2%9C%85Git%E7%9A%84merge%E5%92%8Crebase%E6%9C%89%E4%BB%80%E4%B9%88%E5%8C%BA%E5%88%AB%EF%BC%9F.md)