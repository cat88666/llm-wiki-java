# ✅jstack命令的作用是什么？

所有者: junk01

# ✅jstack命令的作用是什么？

> 原文：[https://www.yuque.com/hollis666/asgng6/hc8uutqs3wnsenr9](https://www.yuque.com/hollis666/asgng6/hc8uutqs3wnsenr9)
> 

# 典型回答

jstack用于生成java虚拟机当前时刻的线程快照。

> 
> 

线程快照是当前java虚拟机内每一条线程正在执行的方法堆栈的集合

生成线程快照的主要目的是定位线程出现长时间停顿的原因，如线程间死锁、死循环、请求外部资源导致的长时间等待等。 

线程出现停顿的时候通过jstack来查看各个线程的调用堆栈，就可以知道没有响应的线程到底在后台做什么事情，或者等待什么资源。 

需要注意：对线程/堆进行Dump时（执行jstack、jmap等命令时），是想要获取线程或者堆在特定时刻的状态和信息。为了确保这些信息的准确性和一致性，JVM在进行Dump时会暂停所有线程。也需要进入安全点才行。

# 扩展知识

## 使用

想要学习一个命令，先来看看帮助，使用jstack -help查看帮助：

-F当’jstack [-l] pid’没有响应的时候强制打印栈信息 -l长列表. 打印关于锁的附加信息,例如属于java.util.concurrent的ownable synchronizers列表. -m打印java和native c/c++框架的所有栈信息. -h | -help打印帮助信息 pid 需要被打印配置信息的java进程id,可以用jps查询.

首先，我们分析这么一段程序的线程情况：

先是用jps查看进程号：

然后使用jstack 查看堆栈信息：

我们可以从这段堆栈信息中看出什么来呢？我们可以看到，当前一共有一条用户级别线程,线程处于runnable状态，[执行到JStackDemo1.java](http://执行到JStackDemo1.java)的第七行。 看下面代码：

线程堆栈信息如下：

我们能看到：

> 
> 

线程的状态： WAITING 线程的调用栈 线程的当前锁住的资源： <0x0000000783e066e0> 线程当前等待的资源：<0x0000000783e066e0>

为什么同时锁住的等待同一个资源：

> 
> 

线程的执行中，先获得了这个对象的 Monitor（对应于 locked <0x0000000783e066e0>）。当执行到 obj.wait(), 线程即放弃了 Monitor的所有权，进入 “wait set”队列（对应于 waiting on <0x0000000783e066e0> ）。