# ✅while(true)和for(;;)哪个性能好？

所有者: junk01

# ✅while(true)和for(;;)哪个性能好？

> 原文：[https://www.yuque.com/hollis666/asgng6/wapd1ptqpu5onwwm](https://www.yuque.com/hollis666/asgng6/wapd1ptqpu5onwwm)
> 

# 典型回答

while(true)和for(;;)都是做无限循环的代码，他俩有啥区别呢？

关于这个问题，网上有很多讨论，说那么多没用，直接反编译，看看字节码有啥区别就行了。

准备两段代码：

分别将他们编译成class文件：

然后再通过javap对class文件进行反编译，然后我们就会发现，两个文件内容，**一模一样！！！**

可以看到，都是通过goto来干的，所以，这两者其实是没啥区别的。用哪个都行

有人愿意用while(true)因为他更清晰的看出来这里是个无限循环。有人愿意用for(;;)，因为有些IDE对于while(true)会给出警告。至于你，爱用啥用啥。