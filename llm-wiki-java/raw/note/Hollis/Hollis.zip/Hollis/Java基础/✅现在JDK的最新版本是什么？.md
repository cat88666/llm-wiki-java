# ✅现在JDK的最新版本是什么？

所有者: junk01

# ✅现在JDK的最新版本是什么？

> 原文：[https://www.yuque.com/hollis666/asgng6/bvygm5vo3wmt1cug](https://www.yuque.com/hollis666/asgng6/bvygm5vo3wmt1cug)
> 

# 典型回答

目前**Java的发布周期是每半年发布一次**，**大概在每年的3月份和9月份都会发布新版本**。

**~~在2023年9月份的时候发布了JDK 21**。~~  

**~~2024年3月19日，JDK22正式发布**。~~

**~~2024年9月17日JDK23正式发布~~**

**2025年3月18日JDK24正式发布**

**2025年9月16日JDK25正式发布**

根据正常的发布节奏，接下来的发布情况应该是：

2026-03 ——> JDK 26

2026-09 ——> JDK 27

2027-03 ——> JDK 28

在JDK 22及之前的版本中，最后一个LTS版本（Long Term Support）是JDK 25。