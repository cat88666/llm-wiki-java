# ✅泛型中K T V E ？ Object等分别代表什么含义。

所有者: junk01

# ✅泛型中K T V E ？ Object等分别代表什么含义。

> 原文：[https://www.yuque.com/hollis666/asgng6/ku0x9c](https://www.yuque.com/hollis666/asgng6/ku0x9c)
> 

E – Element (在集合中使用，因为集合中存放的是元素)

T – Type（Java 类）

K – Key（键）

V – Value（值）

N – Number（数值类型）

？ – 表示不确定的java类型（无限制通配符类型）

S、U、V – 这几个有时候也有，这些字母本身没有特定的含义，它们只是代表某种未指定的类型。一般认为和T差不多。

Object – 是所有类的根类，任何类的对象都可以设置给该Object引用变量，使用的时候可能需要类型强制转换，但是用使用了泛型T、E等这些标识符后，在实际用之前类型就已经确定了，不需要再进行类型强制转换。

# 扩展知识

## 代码示例