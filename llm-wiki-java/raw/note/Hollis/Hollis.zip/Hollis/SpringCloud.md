# SpringCloud

所有者: junk01

本分类共 **27** 篇文章。

- ✅什么是SpringCloud，有哪些组件？
- ✅SpringCloud和Dubbo有什么区别？
- ✅SpringCloud 在Spring6.0后有哪些变化
- ✅什么是Zuul网关，有什么用？
- ✅Ribbon和Nginx的区别是什么？
- ✅Zuul、Gateway和Nginx有什么区别？
- ✅Ribbon是怎么做负载均衡的？
- ✅Hystrix和Sentinel的区别是什么？
- ✅OpenFeign 不支持了怎么办？
- ✅LoadBalancer和Ribbon的区别是什么？为什么用他替代Ribbon？
- ✅在 Spring Cloud 中，服务间的通信有哪些方式？
- ✅为什么需要SpringCloud Gateway，他起到了什么作用？
- ✅Dubbo和Feign有什么区别？
- ✅Eureka和Zookeeper有什么区别？
- ✅介绍一下Eureka的缓存机制
- ✅什么是Eureka的自我保护模式？
- ✅Feign 第一次调用为什么很慢？可能的原因是什么？
- ✅Hystrix熔断器的工作原理是什么？
- ✅介绍一下 Hystrix 的隔离策略，你用哪个？
- ✅Eureka 在 Spring Boot 3.x 之后被移除了，如何替代？
- ✅LoadBalancer支持哪些负载均衡策略？如何修改？
- ✅Feign 和 RestTemplate 有什么不同？
- ✅Feign和OpenFeign 有什么区别？
- ✅OpenFeign 是如何实现负载均衡的？
- ✅OpenFeign如何处理超时？如何处理异常？如何记录客户端日志？
- ✅Feign调用超时，会自动重试吗？如何设置？
- ✅application.yml 和 bootstrap.yml 这两个配置文件有什么区别？

[✅什么是SpringCloud，有哪些组件？](SpringCloud/%E2%9C%85%E4%BB%80%E4%B9%88%E6%98%AFSpringCloud%EF%BC%8C%E6%9C%89%E5%93%AA%E4%BA%9B%E7%BB%84%E4%BB%B6%EF%BC%9F.md)

[✅SpringCloud和Dubbo有什么区别？](SpringCloud/%E2%9C%85SpringCloud%E5%92%8CDubbo%E6%9C%89%E4%BB%80%E4%B9%88%E5%8C%BA%E5%88%AB%EF%BC%9F.md)

[✅SpringCloud 在Spring6.0后有哪些变化](SpringCloud/%E2%9C%85SpringCloud%20%E5%9C%A8Spring6%200%E5%90%8E%E6%9C%89%E5%93%AA%E4%BA%9B%E5%8F%98%E5%8C%96.md)

[✅什么是Zuul网关，有什么用？](SpringCloud/%E2%9C%85%E4%BB%80%E4%B9%88%E6%98%AFZuul%E7%BD%91%E5%85%B3%EF%BC%8C%E6%9C%89%E4%BB%80%E4%B9%88%E7%94%A8%EF%BC%9F.md)

[✅Ribbon和Nginx的区别是什么？](SpringCloud/%E2%9C%85Ribbon%E5%92%8CNginx%E7%9A%84%E5%8C%BA%E5%88%AB%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F.md)

[✅Zuul、Gateway和Nginx有什么区别？](SpringCloud/%E2%9C%85Zuul%E3%80%81Gateway%E5%92%8CNginx%E6%9C%89%E4%BB%80%E4%B9%88%E5%8C%BA%E5%88%AB%EF%BC%9F.md)

[✅Ribbon是怎么做负载均衡的？](SpringCloud/%E2%9C%85Ribbon%E6%98%AF%E6%80%8E%E4%B9%88%E5%81%9A%E8%B4%9F%E8%BD%BD%E5%9D%87%E8%A1%A1%E7%9A%84%EF%BC%9F.md)

[✅Hystrix和Sentinel的区别是什么？](SpringCloud/%E2%9C%85Hystrix%E5%92%8CSentinel%E7%9A%84%E5%8C%BA%E5%88%AB%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F.md)

[✅OpenFeign 不支持了怎么办？](SpringCloud/%E2%9C%85OpenFeign%20%E4%B8%8D%E6%94%AF%E6%8C%81%E4%BA%86%E6%80%8E%E4%B9%88%E5%8A%9E%EF%BC%9F.md)

[✅LoadBalancer和Ribbon的区别是什么？为什么用他替代Ribbon？](SpringCloud/%E2%9C%85LoadBalancer%E5%92%8CRibbon%E7%9A%84%E5%8C%BA%E5%88%AB%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F%E4%B8%BA%E4%BB%80%E4%B9%88%E7%94%A8%E4%BB%96%E6%9B%BF%E4%BB%A3Ribbon%EF%BC%9F.md)

[✅在 Spring Cloud 中，服务间的通信有哪些方式？](SpringCloud/%E2%9C%85%E5%9C%A8%20Spring%20Cloud%20%E4%B8%AD%EF%BC%8C%E6%9C%8D%E5%8A%A1%E9%97%B4%E7%9A%84%E9%80%9A%E4%BF%A1%E6%9C%89%E5%93%AA%E4%BA%9B%E6%96%B9%E5%BC%8F%EF%BC%9F.md)

[✅为什么需要SpringCloud Gateway，他起到了什么作用？](SpringCloud/%E2%9C%85%E4%B8%BA%E4%BB%80%E4%B9%88%E9%9C%80%E8%A6%81SpringCloud%20Gateway%EF%BC%8C%E4%BB%96%E8%B5%B7%E5%88%B0%E4%BA%86%E4%BB%80%E4%B9%88%E4%BD%9C%E7%94%A8%EF%BC%9F.md)

[✅Dubbo和Feign有什么区别？](SpringCloud/%E2%9C%85Dubbo%E5%92%8CFeign%E6%9C%89%E4%BB%80%E4%B9%88%E5%8C%BA%E5%88%AB%EF%BC%9F.md)

[✅Eureka和Zookeeper有什么区别？](SpringCloud/%E2%9C%85Eureka%E5%92%8CZookeeper%E6%9C%89%E4%BB%80%E4%B9%88%E5%8C%BA%E5%88%AB%EF%BC%9F.md)

[✅介绍一下Eureka的缓存机制](SpringCloud/%E2%9C%85%E4%BB%8B%E7%BB%8D%E4%B8%80%E4%B8%8BEureka%E7%9A%84%E7%BC%93%E5%AD%98%E6%9C%BA%E5%88%B6.md)

[✅什么是Eureka的自我保护模式？](SpringCloud/%E2%9C%85%E4%BB%80%E4%B9%88%E6%98%AFEureka%E7%9A%84%E8%87%AA%E6%88%91%E4%BF%9D%E6%8A%A4%E6%A8%A1%E5%BC%8F%EF%BC%9F.md)

[✅Feign 第一次调用为什么很慢？可能的原因是什么？](SpringCloud/%E2%9C%85Feign%20%E7%AC%AC%E4%B8%80%E6%AC%A1%E8%B0%83%E7%94%A8%E4%B8%BA%E4%BB%80%E4%B9%88%E5%BE%88%E6%85%A2%EF%BC%9F%E5%8F%AF%E8%83%BD%E7%9A%84%E5%8E%9F%E5%9B%A0%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F.md)

[✅Hystrix熔断器的工作原理是什么？](SpringCloud/%E2%9C%85Hystrix%E7%86%94%E6%96%AD%E5%99%A8%E7%9A%84%E5%B7%A5%E4%BD%9C%E5%8E%9F%E7%90%86%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F.md)

[✅介绍一下 Hystrix 的隔离策略，你用哪个？](SpringCloud/%E2%9C%85%E4%BB%8B%E7%BB%8D%E4%B8%80%E4%B8%8B%20Hystrix%20%E7%9A%84%E9%9A%94%E7%A6%BB%E7%AD%96%E7%95%A5%EF%BC%8C%E4%BD%A0%E7%94%A8%E5%93%AA%E4%B8%AA%EF%BC%9F.md)

[✅Eureka 在 Spring Boot 3.x 之后被移除了，如何替代？](SpringCloud/%E2%9C%85Eureka%20%E5%9C%A8%20Spring%20Boot%203%20x%20%E4%B9%8B%E5%90%8E%E8%A2%AB%E7%A7%BB%E9%99%A4%E4%BA%86%EF%BC%8C%E5%A6%82%E4%BD%95%E6%9B%BF%E4%BB%A3%EF%BC%9F.md)

[✅LoadBalancer支持哪些负载均衡策略？如何修改？](SpringCloud/%E2%9C%85LoadBalancer%E6%94%AF%E6%8C%81%E5%93%AA%E4%BA%9B%E8%B4%9F%E8%BD%BD%E5%9D%87%E8%A1%A1%E7%AD%96%E7%95%A5%EF%BC%9F%E5%A6%82%E4%BD%95%E4%BF%AE%E6%94%B9%EF%BC%9F.md)

[✅Feign 和 RestTemplate 有什么不同？](SpringCloud/%E2%9C%85Feign%20%E5%92%8C%20RestTemplate%20%E6%9C%89%E4%BB%80%E4%B9%88%E4%B8%8D%E5%90%8C%EF%BC%9F.md)

[✅Feign和OpenFeign 有什么区别？](SpringCloud/%E2%9C%85Feign%E5%92%8COpenFeign%20%E6%9C%89%E4%BB%80%E4%B9%88%E5%8C%BA%E5%88%AB%EF%BC%9F.md)

[✅OpenFeign 是如何实现负载均衡的？](SpringCloud/%E2%9C%85OpenFeign%20%E6%98%AF%E5%A6%82%E4%BD%95%E5%AE%9E%E7%8E%B0%E8%B4%9F%E8%BD%BD%E5%9D%87%E8%A1%A1%E7%9A%84%EF%BC%9F.md)

[✅OpenFeign如何处理超时？如何处理异常？如何记录客户端日志？](SpringCloud/%E2%9C%85OpenFeign%E5%A6%82%E4%BD%95%E5%A4%84%E7%90%86%E8%B6%85%E6%97%B6%EF%BC%9F%E5%A6%82%E4%BD%95%E5%A4%84%E7%90%86%E5%BC%82%E5%B8%B8%EF%BC%9F%E5%A6%82%E4%BD%95%E8%AE%B0%E5%BD%95%E5%AE%A2%E6%88%B7%E7%AB%AF%E6%97%A5%E5%BF%97%EF%BC%9F.md)

[✅Feign调用超时，会自动重试吗？如何设置？](SpringCloud/%E2%9C%85Feign%E8%B0%83%E7%94%A8%E8%B6%85%E6%97%B6%EF%BC%8C%E4%BC%9A%E8%87%AA%E5%8A%A8%E9%87%8D%E8%AF%95%E5%90%97%EF%BC%9F%E5%A6%82%E4%BD%95%E8%AE%BE%E7%BD%AE%EF%BC%9F.md)

[✅application.yml 和 bootstrap.yml 这两个配置文件有什么区别？](SpringCloud/%E2%9C%85application%20yml%20%E5%92%8C%20bootstrap%20yml%20%E8%BF%99%E4%B8%A4%E4%B8%AA%E9%85%8D%E7%BD%AE%E6%96%87%E4%BB%B6%E6%9C%89%E4%BB%80%E4%B9%88%E5%8C%BA%E5%88%AB%EF%BC%9F.md)